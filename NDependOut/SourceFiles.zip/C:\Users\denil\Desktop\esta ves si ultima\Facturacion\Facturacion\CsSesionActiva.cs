﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facturacion
{
    internal class CsSesionActiva
    {

        public static string NombreVendedor { get; set; }
        public static string Rol { get; set; }
        public static string EmpleadoID { get; set; }

        public static int EmpleadoEditarID { get; set; }
        public static string NombresEmpleadoEditarID { get; set; }
    }
}
