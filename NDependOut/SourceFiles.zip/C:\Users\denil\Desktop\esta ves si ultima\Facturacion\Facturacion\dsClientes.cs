﻿namespace Facturacion
{
}

namespace Facturacion
{
}

namespace Facturacion
{
}

namespace Facturacion
{
}

namespace Facturacion
{
}

namespace Facturacion
{
}

namespace Facturacion
{
}

namespace Facturacion
{
}
namespace Facturacion.dsClientesTableAdapters {
    
    
    public partial class spListarClientesTableAdapter {
    }
}
