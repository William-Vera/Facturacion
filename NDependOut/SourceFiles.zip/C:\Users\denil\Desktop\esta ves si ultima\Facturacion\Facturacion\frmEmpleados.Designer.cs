﻿namespace Facturacion
{
    partial class frmEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            panel9 = new Panel();
            dgvAgregar = new DataGridView();
            panel1 = new Panel();
            btnAgregar = new Button();
            comboBox1 = new ComboBox();
            button1 = new Button();
            textBox1 = new TextBox();
            label1 = new Label();
            button2 = new Button();
            panel2 = new Panel();
            label22 = new Label();
            txtContrasenia = new TextBox();
            comboBox4 = new ComboBox();
            label2 = new Label();
            comboBox5 = new ComboBox();
            label3 = new Label();
            label4 = new Label();
            txtUser = new TextBox();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            txtApellidos = new TextBox();
            txtNombres = new TextBox();
            txtcedula = new TextBox();
            tabPage2 = new TabPage();
            panel8 = new Panel();
            dgvEditar = new DataGridView();
            panel3 = new Panel();
            comboBox2 = new ComboBox();
            btnBuscarEditar = new Button();
            txtBuscarEditar = new TextBox();
            label5 = new Label();
            btnLimpiarEditar = new Button();
            panel4 = new Panel();
            btnEditar = new Button();
            cbxEstadoEditar = new ComboBox();
            label6 = new Label();
            cbxRolEditar = new ComboBox();
            label7 = new Label();
            label8 = new Label();
            txtUserEditar = new TextBox();
            btnEditarPass = new Button();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            txtApellidoEditar = new TextBox();
            txtNombreEditar = new TextBox();
            txtCedulaEditar = new TextBox();
            tabPage3 = new TabPage();
            panel7 = new Panel();
            comboBox3 = new ComboBox();
            btnBuscarEliminar = new Button();
            txtBuscarEliminar = new TextBox();
            label9 = new Label();
            btnLimpiarEliminar = new Button();
            panel6 = new Panel();
            dgvEliminar = new DataGridView();
            panel5 = new Panel();
            cbxEstadoEliminar = new ComboBox();
            label15 = new Label();
            cbxRolEliminar = new ComboBox();
            label14 = new Label();
            label13 = new Label();
            txtNomUser = new TextBox();
            btnEliminar = new Button();
            label12 = new Label();
            label10 = new Label();
            label11 = new Label();
            txtApellidoEliminar = new TextBox();
            txtNombreEliminar = new TextBox();
            txtCedulaEliminar = new TextBox();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvAgregar).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            tabPage2.SuspendLayout();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvEditar).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            tabPage3.SuspendLayout();
            panel7.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvEliminar).BeginInit();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1200, 603);
            tabControl1.TabIndex = 1;
            tabControl1.Click += tabControl1_Click;
            // 
            // tabPage1
            // 
            tabPage1.BorderStyle = BorderStyle.Fixed3D;
            tabPage1.Controls.Add(panel9);
            tabPage1.Controls.Add(panel1);
            tabPage1.Controls.Add(panel2);
            tabPage1.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabPage1.Location = new Point(4, 28);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1192, 571);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Agregar";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            panel9.BorderStyle = BorderStyle.Fixed3D;
            panel9.Controls.Add(dgvAgregar);
            panel9.Dock = DockStyle.Fill;
            panel9.Location = new Point(3, 181);
            panel9.Name = "panel9";
            panel9.Size = new Size(1182, 383);
            panel9.TabIndex = 40;
            // 
            // dgvAgregar
            // 
            dgvAgregar.AllowUserToAddRows = false;
            dgvAgregar.AllowUserToDeleteRows = false;
            dgvAgregar.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAgregar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAgregar.Dock = DockStyle.Fill;
            dgvAgregar.Location = new Point(0, 0);
            dgvAgregar.Name = "dgvAgregar";
            dgvAgregar.ReadOnly = true;
            dgvAgregar.Size = new Size(1178, 379);
            dgvAgregar.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(btnAgregar);
            panel1.Controls.Add(comboBox1);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(3, 92);
            panel1.Name = "panel1";
            panel1.Size = new Size(1182, 89);
            panel1.TabIndex = 38;
            // 
            // btnAgregar
            // 
            btnAgregar.Anchor = AnchorStyles.Right;
            btnAgregar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregar.Location = new Point(1003, 30);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(167, 35);
            btnAgregar.TabIndex = 40;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // comboBox1
            // 
            comboBox1.Anchor = AnchorStyles.Left;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Font = new Font("Times New Roman", 12F);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Cedula", "Nombre", "Apellido", "Usuario", "Rol", "Estado" });
            comboBox1.Location = new Point(358, 29);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(226, 27);
            comboBox1.TabIndex = 34;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Right;
            button1.Font = new Font("Arial", 12F, FontStyle.Bold);
            button1.Location = new Point(635, 30);
            button1.Name = "button1";
            button1.Size = new Size(167, 35);
            button1.TabIndex = 33;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Left;
            textBox1.Font = new Font("Times New Roman", 12F);
            textBox1.Location = new Point(92, 28);
            textBox1.Margin = new Padding(3, 3, 30, 3);
            textBox1.MaxLength = 10;
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(238, 27);
            textBox1.TabIndex = 30;
            textBox1.KeyPress += textBox1_KeyPress;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left;
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold);
            label1.Location = new Point(18, 32);
            label1.Name = "label1";
            label1.Size = new Size(70, 19);
            label1.TabIndex = 31;
            label1.Text = "Buscar:";
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Right;
            button2.Font = new Font("Arial", 12F, FontStyle.Bold);
            button2.Location = new Point(820, 30);
            button2.Name = "button2";
            button2.Size = new Size(167, 35);
            button2.TabIndex = 29;
            button2.Text = "Limpiar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(label22);
            panel2.Controls.Add(txtContrasenia);
            panel2.Controls.Add(comboBox4);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(comboBox5);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(txtUser);
            panel2.Controls.Add(label19);
            panel2.Controls.Add(label20);
            panel2.Controls.Add(label21);
            panel2.Controls.Add(txtApellidos);
            panel2.Controls.Add(txtNombres);
            panel2.Controls.Add(txtcedula);
            panel2.Dock = DockStyle.Top;
            panel2.Font = new Font("Arial", 12F, FontStyle.Bold);
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(1182, 89);
            panel2.TabIndex = 39;
            // 
            // label22
            // 
            label22.Anchor = AnchorStyles.Left;
            label22.AutoSize = true;
            label22.Font = new Font("Arial", 12F, FontStyle.Bold);
            label22.Location = new Point(701, 12);
            label22.Name = "label22";
            label22.Size = new Size(98, 19);
            label22.TabIndex = 41;
            label22.Text = "Contraseña";
            // 
            // txtContrasenia
            // 
            txtContrasenia.Anchor = AnchorStyles.Left;
            txtContrasenia.Font = new Font("Times New Roman", 12F);
            txtContrasenia.Location = new Point(696, 34);
            txtContrasenia.Name = "txtContrasenia";
            txtContrasenia.Size = new Size(158, 26);
            txtContrasenia.TabIndex = 40;
            // 
            // comboBox4
            // 
            comboBox4.Anchor = AnchorStyles.Left;
            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox4.Font = new Font("Times New Roman", 12F);
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "Activado", "Desactivado" });
            comboBox4.Location = new Point(1025, 36);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(121, 27);
            comboBox4.TabIndex = 39;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left;
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold);
            label2.Location = new Point(1028, 12);
            label2.Name = "label2";
            label2.Size = new Size(63, 19);
            label2.TabIndex = 38;
            label2.Text = "Estado";
            // 
            // comboBox5
            // 
            comboBox5.Anchor = AnchorStyles.Left;
            comboBox5.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox5.Font = new Font("Times New Roman", 12F);
            comboBox5.FormattingEnabled = true;
            comboBox5.Location = new Point(882, 36);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(121, 27);
            comboBox5.TabIndex = 37;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Left;
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Bold);
            label3.Location = new Point(885, 12);
            label3.Name = "label3";
            label3.Size = new Size(35, 19);
            label3.TabIndex = 36;
            label3.Text = "Rol";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Left;
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Bold);
            label4.Location = new Point(519, 12);
            label4.Name = "label4";
            label4.Size = new Size(69, 19);
            label4.TabIndex = 34;
            label4.Text = "Usuario";
            // 
            // txtUser
            // 
            txtUser.Anchor = AnchorStyles.Left;
            txtUser.Font = new Font("Times New Roman", 12F);
            txtUser.Location = new Point(514, 34);
            txtUser.MaxLength = 25;
            txtUser.Name = "txtUser";
            txtUser.Size = new Size(158, 26);
            txtUser.TabIndex = 33;
            // 
            // label19
            // 
            label19.Anchor = AnchorStyles.Left;
            label19.AutoSize = true;
            label19.Font = new Font("Arial", 12F, FontStyle.Bold);
            label19.Location = new Point(162, 12);
            label19.Name = "label19";
            label19.Size = new Size(79, 19);
            label19.TabIndex = 32;
            label19.Text = "Nombres";
            // 
            // label20
            // 
            label20.Anchor = AnchorStyles.Left;
            label20.AutoSize = true;
            label20.Font = new Font("Arial", 12F, FontStyle.Bold);
            label20.Location = new Point(343, 12);
            label20.Name = "label20";
            label20.Size = new Size(80, 19);
            label20.TabIndex = 27;
            label20.Text = "Apellidos";
            // 
            // label21
            // 
            label21.Anchor = AnchorStyles.Left;
            label21.AutoSize = true;
            label21.Font = new Font("Arial", 12F, FontStyle.Bold);
            label21.Location = new Point(17, 12);
            label21.Name = "label21";
            label21.Size = new Size(63, 19);
            label21.TabIndex = 26;
            label21.Text = "Cedula";
            // 
            // txtApellidos
            // 
            txtApellidos.Anchor = AnchorStyles.Left;
            txtApellidos.Font = new Font("Times New Roman", 12F);
            txtApellidos.Location = new Point(338, 34);
            txtApellidos.MaxLength = 30;
            txtApellidos.Name = "txtApellidos";
            txtApellidos.Size = new Size(158, 26);
            txtApellidos.TabIndex = 25;
            // 
            // txtNombres
            // 
            txtNombres.Anchor = AnchorStyles.Left;
            txtNombres.Font = new Font("Times New Roman", 12F);
            txtNombres.Location = new Point(156, 34);
            txtNombres.MaxLength = 30;
            txtNombres.Name = "txtNombres";
            txtNombres.Size = new Size(158, 26);
            txtNombres.TabIndex = 24;
            // 
            // txtcedula
            // 
            txtcedula.Anchor = AnchorStyles.Left;
            txtcedula.Font = new Font("Times New Roman", 12F);
            txtcedula.Location = new Point(12, 34);
            txtcedula.MaxLength = 10;
            txtcedula.Name = "txtcedula";
            txtcedula.Size = new Size(125, 26);
            txtcedula.TabIndex = 23;
            txtcedula.KeyPress += txtcedula_KeyPress;
            // 
            // tabPage2
            // 
            tabPage2.BorderStyle = BorderStyle.Fixed3D;
            tabPage2.Controls.Add(panel8);
            tabPage2.Controls.Add(panel3);
            tabPage2.Controls.Add(panel4);
            tabPage2.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabPage2.Location = new Point(4, 28);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1192, 571);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Editar";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            panel8.BorderStyle = BorderStyle.Fixed3D;
            panel8.Controls.Add(dgvEditar);
            panel8.Dock = DockStyle.Fill;
            panel8.Location = new Point(3, 181);
            panel8.Name = "panel8";
            panel8.Size = new Size(1182, 383);
            panel8.TabIndex = 38;
            // 
            // dgvEditar
            // 
            dgvEditar.AllowUserToAddRows = false;
            dgvEditar.AllowUserToDeleteRows = false;
            dgvEditar.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEditar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEditar.Dock = DockStyle.Fill;
            dgvEditar.Location = new Point(0, 0);
            dgvEditar.Name = "dgvEditar";
            dgvEditar.ReadOnly = true;
            dgvEditar.Size = new Size(1178, 379);
            dgvEditar.TabIndex = 0;
            dgvEditar.CellClick += dgvEditar_CellClick;
            dgvEditar.CellContentClick += dgvEditar_CellContentClick_1;
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.Fixed3D;
            panel3.Controls.Add(comboBox2);
            panel3.Controls.Add(btnBuscarEditar);
            panel3.Controls.Add(txtBuscarEditar);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(btnLimpiarEditar);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(3, 92);
            panel3.Name = "panel3";
            panel3.Size = new Size(1182, 89);
            panel3.TabIndex = 37;
            // 
            // comboBox2
            // 
            comboBox2.Anchor = AnchorStyles.Right;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.Font = new Font("Times New Roman", 12F);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Cedula", "Nombre", "Apellido", "Usuario", "Rol", "Estado" });
            comboBox2.Location = new Point(407, 30);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(230, 27);
            comboBox2.TabIndex = 34;
            // 
            // btnBuscarEditar
            // 
            btnBuscarEditar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnBuscarEditar.Font = new Font("Arial", 12F, FontStyle.Bold);
            btnBuscarEditar.Location = new Point(709, 30);
            btnBuscarEditar.Name = "btnBuscarEditar";
            btnBuscarEditar.Size = new Size(171, 35);
            btnBuscarEditar.TabIndex = 33;
            btnBuscarEditar.Text = "Buscar";
            btnBuscarEditar.UseVisualStyleBackColor = true;
            btnBuscarEditar.Click += btnBuscarEditar_Click;
            // 
            // txtBuscarEditar
            // 
            txtBuscarEditar.Anchor = AnchorStyles.Left;
            txtBuscarEditar.Font = new Font("Times New Roman", 12F);
            txtBuscarEditar.Location = new Point(92, 28);
            txtBuscarEditar.Margin = new Padding(3, 3, 30, 3);
            txtBuscarEditar.MaxLength = 10;
            txtBuscarEditar.Multiline = true;
            txtBuscarEditar.Name = "txtBuscarEditar";
            txtBuscarEditar.Size = new Size(242, 27);
            txtBuscarEditar.TabIndex = 30;
            txtBuscarEditar.KeyPress += txtBuscarEditar_KeyPress;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Left;
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Bold);
            label5.Location = new Point(18, 32);
            label5.Name = "label5";
            label5.Size = new Size(70, 19);
            label5.TabIndex = 31;
            label5.Text = "Buscar:";
            // 
            // btnLimpiarEditar
            // 
            btnLimpiarEditar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLimpiarEditar.Font = new Font("Arial", 12F, FontStyle.Bold);
            btnLimpiarEditar.Location = new Point(938, 30);
            btnLimpiarEditar.Name = "btnLimpiarEditar";
            btnLimpiarEditar.Size = new Size(171, 35);
            btnLimpiarEditar.TabIndex = 29;
            btnLimpiarEditar.Text = "Limpiar";
            btnLimpiarEditar.UseVisualStyleBackColor = true;
            btnLimpiarEditar.Click += btnLimpiarEditar_Click;
            // 
            // panel4
            // 
            panel4.BorderStyle = BorderStyle.Fixed3D;
            panel4.Controls.Add(btnEditar);
            panel4.Controls.Add(cbxEstadoEditar);
            panel4.Controls.Add(label6);
            panel4.Controls.Add(cbxRolEditar);
            panel4.Controls.Add(label7);
            panel4.Controls.Add(label8);
            panel4.Controls.Add(txtUserEditar);
            panel4.Controls.Add(btnEditarPass);
            panel4.Controls.Add(label16);
            panel4.Controls.Add(label17);
            panel4.Controls.Add(label18);
            panel4.Controls.Add(txtApellidoEditar);
            panel4.Controls.Add(txtNombreEditar);
            panel4.Controls.Add(txtCedulaEditar);
            panel4.Dock = DockStyle.Top;
            panel4.Font = new Font("Arial", 12F, FontStyle.Bold);
            panel4.Location = new Point(3, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(1182, 89);
            panel4.TabIndex = 36;
            // 
            // btnEditar
            // 
            btnEditar.Anchor = AnchorStyles.Right;
            btnEditar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditar.Location = new Point(997, 46);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(171, 35);
            btnEditar.TabIndex = 40;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // cbxEstadoEditar
            // 
            cbxEstadoEditar.Anchor = AnchorStyles.Left;
            cbxEstadoEditar.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxEstadoEditar.Font = new Font("Times New Roman", 12F);
            cbxEstadoEditar.FormattingEnabled = true;
            cbxEstadoEditar.Location = new Point(830, 36);
            cbxEstadoEditar.Name = "cbxEstadoEditar";
            cbxEstadoEditar.Size = new Size(121, 27);
            cbxEstadoEditar.TabIndex = 39;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Left;
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 12F, FontStyle.Bold);
            label6.Location = new Point(833, 12);
            label6.Name = "label6";
            label6.Size = new Size(63, 19);
            label6.TabIndex = 38;
            label6.Text = "Estado";
            // 
            // cbxRolEditar
            // 
            cbxRolEditar.Anchor = AnchorStyles.Left;
            cbxRolEditar.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxRolEditar.Font = new Font("Times New Roman", 12F);
            cbxRolEditar.FormattingEnabled = true;
            cbxRolEditar.Location = new Point(687, 36);
            cbxRolEditar.Name = "cbxRolEditar";
            cbxRolEditar.Size = new Size(121, 27);
            cbxRolEditar.TabIndex = 37;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Left;
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 12F, FontStyle.Bold);
            label7.Location = new Point(690, 12);
            label7.Name = "label7";
            label7.Size = new Size(35, 19);
            label7.TabIndex = 36;
            label7.Text = "Rol";
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Left;
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 12F, FontStyle.Bold);
            label8.Location = new Point(519, 12);
            label8.Name = "label8";
            label8.Size = new Size(69, 19);
            label8.TabIndex = 34;
            label8.Text = "Usuario";
            // 
            // txtUserEditar
            // 
            txtUserEditar.Anchor = AnchorStyles.Left;
            txtUserEditar.Font = new Font("Times New Roman", 12F);
            txtUserEditar.Location = new Point(514, 34);
            txtUserEditar.Name = "txtUserEditar";
            txtUserEditar.Size = new Size(158, 26);
            txtUserEditar.TabIndex = 33;
            // 
            // btnEditarPass
            // 
            btnEditarPass.Anchor = AnchorStyles.Right;
            btnEditarPass.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditarPass.Location = new Point(997, 6);
            btnEditarPass.Name = "btnEditarPass";
            btnEditarPass.Size = new Size(171, 35);
            btnEditarPass.TabIndex = 28;
            btnEditarPass.Text = "Editar Contraseña";
            btnEditarPass.UseVisualStyleBackColor = true;
            btnEditarPass.Click += btnEditarPass_Click;
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.Left;
            label16.AutoSize = true;
            label16.Font = new Font("Arial", 12F, FontStyle.Bold);
            label16.Location = new Point(162, 12);
            label16.Name = "label16";
            label16.Size = new Size(79, 19);
            label16.TabIndex = 32;
            label16.Text = "Nombres";
            // 
            // label17
            // 
            label17.Anchor = AnchorStyles.Left;
            label17.AutoSize = true;
            label17.Font = new Font("Arial", 12F, FontStyle.Bold);
            label17.Location = new Point(343, 12);
            label17.Name = "label17";
            label17.Size = new Size(80, 19);
            label17.TabIndex = 27;
            label17.Text = "Apellidos";
            // 
            // label18
            // 
            label18.Anchor = AnchorStyles.Left;
            label18.AutoSize = true;
            label18.Font = new Font("Arial", 12F, FontStyle.Bold);
            label18.Location = new Point(17, 12);
            label18.Name = "label18";
            label18.Size = new Size(63, 19);
            label18.TabIndex = 26;
            label18.Text = "Cedula";
            // 
            // txtApellidoEditar
            // 
            txtApellidoEditar.Anchor = AnchorStyles.Left;
            txtApellidoEditar.Font = new Font("Times New Roman", 12F);
            txtApellidoEditar.Location = new Point(338, 34);
            txtApellidoEditar.Name = "txtApellidoEditar";
            txtApellidoEditar.Size = new Size(158, 26);
            txtApellidoEditar.TabIndex = 25;
            txtApellidoEditar.TextChanged += textBox3_TextChanged;
            // 
            // txtNombreEditar
            // 
            txtNombreEditar.Anchor = AnchorStyles.Left;
            txtNombreEditar.Font = new Font("Times New Roman", 12F);
            txtNombreEditar.Location = new Point(156, 34);
            txtNombreEditar.Name = "txtNombreEditar";
            txtNombreEditar.Size = new Size(158, 26);
            txtNombreEditar.TabIndex = 24;
            // 
            // txtCedulaEditar
            // 
            txtCedulaEditar.Anchor = AnchorStyles.Left;
            txtCedulaEditar.Font = new Font("Times New Roman", 12F);
            txtCedulaEditar.Location = new Point(12, 34);
            txtCedulaEditar.MaxLength = 10;
            txtCedulaEditar.Name = "txtCedulaEditar";
            txtCedulaEditar.Size = new Size(125, 26);
            txtCedulaEditar.TabIndex = 23;
            txtCedulaEditar.KeyPress += txtCedulaEditar_KeyPress;
            // 
            // tabPage3
            // 
            tabPage3.BorderStyle = BorderStyle.Fixed3D;
            tabPage3.Controls.Add(panel7);
            tabPage3.Controls.Add(panel6);
            tabPage3.Controls.Add(panel5);
            tabPage3.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabPage3.Location = new Point(4, 28);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(1192, 571);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Eliminar";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            panel7.BorderStyle = BorderStyle.Fixed3D;
            panel7.Controls.Add(comboBox3);
            panel7.Controls.Add(btnBuscarEliminar);
            panel7.Controls.Add(txtBuscarEliminar);
            panel7.Controls.Add(label9);
            panel7.Controls.Add(btnLimpiarEliminar);
            panel7.Dock = DockStyle.Top;
            panel7.Location = new Point(3, 92);
            panel7.Name = "panel7";
            panel7.Size = new Size(1182, 89);
            panel7.TabIndex = 35;
            // 
            // comboBox3
            // 
            comboBox3.Anchor = AnchorStyles.Right;
            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox3.Font = new Font("Times New Roman", 12F);
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Cedula", "Nombres", "Apellidos" });
            comboBox3.Location = new Point(407, 30);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(230, 27);
            comboBox3.TabIndex = 34;
            // 
            // btnBuscarEliminar
            // 
            btnBuscarEliminar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnBuscarEliminar.Font = new Font("Arial", 12F, FontStyle.Bold);
            btnBuscarEliminar.Location = new Point(709, 30);
            btnBuscarEliminar.Name = "btnBuscarEliminar";
            btnBuscarEliminar.Size = new Size(171, 35);
            btnBuscarEliminar.TabIndex = 33;
            btnBuscarEliminar.Text = "Buscar";
            btnBuscarEliminar.UseVisualStyleBackColor = true;
            // 
            // txtBuscarEliminar
            // 
            txtBuscarEliminar.Anchor = AnchorStyles.Left;
            txtBuscarEliminar.Font = new Font("Times New Roman", 12F);
            txtBuscarEliminar.Location = new Point(92, 28);
            txtBuscarEliminar.Margin = new Padding(3, 3, 30, 3);
            txtBuscarEliminar.MaxLength = 10;
            txtBuscarEliminar.Multiline = true;
            txtBuscarEliminar.Name = "txtBuscarEliminar";
            txtBuscarEliminar.Size = new Size(242, 27);
            txtBuscarEliminar.TabIndex = 30;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Left;
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 12F, FontStyle.Bold);
            label9.Location = new Point(18, 32);
            label9.Name = "label9";
            label9.Size = new Size(70, 19);
            label9.TabIndex = 31;
            label9.Text = "Buscar:";
            // 
            // btnLimpiarEliminar
            // 
            btnLimpiarEliminar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLimpiarEliminar.Font = new Font("Arial", 12F, FontStyle.Bold);
            btnLimpiarEliminar.Location = new Point(938, 30);
            btnLimpiarEliminar.Name = "btnLimpiarEliminar";
            btnLimpiarEliminar.Size = new Size(171, 35);
            btnLimpiarEliminar.TabIndex = 29;
            btnLimpiarEliminar.Text = "Limpiar";
            btnLimpiarEliminar.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            panel6.BorderStyle = BorderStyle.Fixed3D;
            panel6.Controls.Add(dgvEliminar);
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(3, 92);
            panel6.Name = "panel6";
            panel6.Size = new Size(1182, 472);
            panel6.TabIndex = 34;
            // 
            // dgvEliminar
            // 
            dgvEliminar.AllowUserToAddRows = false;
            dgvEliminar.AllowUserToDeleteRows = false;
            dgvEliminar.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEliminar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEliminar.Dock = DockStyle.Fill;
            dgvEliminar.Location = new Point(0, 0);
            dgvEliminar.Name = "dgvEliminar";
            dgvEliminar.ReadOnly = true;
            dgvEliminar.ScrollBars = ScrollBars.Vertical;
            dgvEliminar.Size = new Size(1178, 468);
            dgvEliminar.TabIndex = 22;
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.Fixed3D;
            panel5.Controls.Add(cbxEstadoEliminar);
            panel5.Controls.Add(label15);
            panel5.Controls.Add(cbxRolEliminar);
            panel5.Controls.Add(label14);
            panel5.Controls.Add(label13);
            panel5.Controls.Add(txtNomUser);
            panel5.Controls.Add(btnEliminar);
            panel5.Controls.Add(label12);
            panel5.Controls.Add(label10);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(txtApellidoEliminar);
            panel5.Controls.Add(txtNombreEliminar);
            panel5.Controls.Add(txtCedulaEliminar);
            panel5.Dock = DockStyle.Top;
            panel5.Font = new Font("Arial", 12F, FontStyle.Bold);
            panel5.Location = new Point(3, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(1182, 89);
            panel5.TabIndex = 33;
            // 
            // cbxEstadoEliminar
            // 
            cbxEstadoEliminar.Anchor = AnchorStyles.Left;
            cbxEstadoEliminar.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxEstadoEliminar.Enabled = false;
            cbxEstadoEliminar.Font = new Font("Times New Roman", 12F);
            cbxEstadoEliminar.FormattingEnabled = true;
            cbxEstadoEliminar.Location = new Point(830, 36);
            cbxEstadoEliminar.Name = "cbxEstadoEliminar";
            cbxEstadoEliminar.Size = new Size(121, 27);
            cbxEstadoEliminar.TabIndex = 39;
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.Left;
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 12F, FontStyle.Bold);
            label15.Location = new Point(833, 12);
            label15.Name = "label15";
            label15.Size = new Size(63, 19);
            label15.TabIndex = 38;
            label15.Text = "Estado";
            // 
            // cbxRolEliminar
            // 
            cbxRolEliminar.Anchor = AnchorStyles.Left;
            cbxRolEliminar.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxRolEliminar.Enabled = false;
            cbxRolEliminar.Font = new Font("Times New Roman", 12F);
            cbxRolEliminar.FormattingEnabled = true;
            cbxRolEliminar.Location = new Point(687, 36);
            cbxRolEliminar.Name = "cbxRolEliminar";
            cbxRolEliminar.Size = new Size(121, 27);
            cbxRolEliminar.TabIndex = 37;
            // 
            // label14
            // 
            label14.Anchor = AnchorStyles.Left;
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 12F, FontStyle.Bold);
            label14.Location = new Point(690, 12);
            label14.Name = "label14";
            label14.Size = new Size(35, 19);
            label14.TabIndex = 36;
            label14.Text = "Rol";
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Left;
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 12F, FontStyle.Bold);
            label13.Location = new Point(519, 12);
            label13.Name = "label13";
            label13.Size = new Size(69, 19);
            label13.TabIndex = 34;
            label13.Text = "Usuario";
            // 
            // txtNomUser
            // 
            txtNomUser.Anchor = AnchorStyles.Left;
            txtNomUser.Enabled = false;
            txtNomUser.Font = new Font("Times New Roman", 12F);
            txtNomUser.Location = new Point(514, 34);
            txtNomUser.Name = "txtNomUser";
            txtNomUser.Size = new Size(158, 26);
            txtNomUser.TabIndex = 33;
            // 
            // btnEliminar
            // 
            btnEliminar.Anchor = AnchorStyles.Right;
            btnEliminar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEliminar.Location = new Point(997, 33);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(171, 35);
            btnEliminar.TabIndex = 28;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Left;
            label12.AutoSize = true;
            label12.Font = new Font("Arial", 12F, FontStyle.Bold);
            label12.Location = new Point(162, 12);
            label12.Name = "label12";
            label12.Size = new Size(79, 19);
            label12.TabIndex = 32;
            label12.Text = "Nombres";
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Left;
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 12F, FontStyle.Bold);
            label10.Location = new Point(343, 12);
            label10.Name = "label10";
            label10.Size = new Size(80, 19);
            label10.TabIndex = 27;
            label10.Text = "Apellidos";
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Left;
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 12F, FontStyle.Bold);
            label11.Location = new Point(17, 12);
            label11.Name = "label11";
            label11.Size = new Size(63, 19);
            label11.TabIndex = 26;
            label11.Text = "Cedula";
            // 
            // txtApellidoEliminar
            // 
            txtApellidoEliminar.Anchor = AnchorStyles.Left;
            txtApellidoEliminar.Enabled = false;
            txtApellidoEliminar.Font = new Font("Times New Roman", 12F);
            txtApellidoEliminar.Location = new Point(338, 34);
            txtApellidoEliminar.Name = "txtApellidoEliminar";
            txtApellidoEliminar.Size = new Size(158, 26);
            txtApellidoEliminar.TabIndex = 25;
            // 
            // txtNombreEliminar
            // 
            txtNombreEliminar.Anchor = AnchorStyles.Left;
            txtNombreEliminar.Enabled = false;
            txtNombreEliminar.Font = new Font("Times New Roman", 12F);
            txtNombreEliminar.Location = new Point(156, 34);
            txtNombreEliminar.Name = "txtNombreEliminar";
            txtNombreEliminar.Size = new Size(158, 26);
            txtNombreEliminar.TabIndex = 24;
            // 
            // txtCedulaEliminar
            // 
            txtCedulaEliminar.Anchor = AnchorStyles.Left;
            txtCedulaEliminar.Enabled = false;
            txtCedulaEliminar.Font = new Font("Times New Roman", 12F);
            txtCedulaEliminar.Location = new Point(12, 34);
            txtCedulaEliminar.MaxLength = 10;
            txtCedulaEliminar.Name = "txtCedulaEliminar";
            txtCedulaEliminar.Size = new Size(125, 26);
            txtCedulaEliminar.TabIndex = 23;
            // 
            // frmEmpleados
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1200, 603);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmEmpleados";
            Text = "frmEmpleados";
            Load += frmEmpleados_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvAgregar).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            tabPage2.ResumeLayout(false);
            panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvEditar).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            tabPage3.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvEliminar).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private Panel panel6;
        private DataGridView dgvEliminar;
        private Panel panel5;
        private ComboBox comboBox3;
        private Button btnBuscarEliminar;
        private Button btnEliminar;
        private Label label12;
        private Label label10;
        private Button btnLimpiarEliminar;
        private Label label11;
        private Label label9;
        private TextBox txtApellidoEliminar;
        private TextBox txtBuscarEliminar;
        private TextBox txtNombreEliminar;
        private TextBox txtCedulaEliminar;
        private Panel panel7;
        private Label label13;
        private TextBox txtNomUser;
        private ComboBox cbxEstadoEliminar;
        private Label label15;
        private ComboBox cbxRolEliminar;
        private Label label14;
        private Panel panel3;
        private ComboBox comboBox2;
        private Button btnBuscarEditar;
        private TextBox txtBuscarEditar;
        private Label label5;
        private Button btnLimpiarEditar;
        private Panel panel4;
        private ComboBox cbxEstadoEditar;
        private Label label6;
        private ComboBox cbxRolEditar;
        private Label label7;
        private Label label8;
        private TextBox txtUserEditar;
        private Button btnEditarPass;
        private Label label16;
        private Label label17;
        private Label label18;
        private TextBox txtApellidoEditar;
        private TextBox txtNombreEditar;
        private TextBox txtCedulaEditar;
        private Panel panel8;
        private DataGridView dgvEditar;
        private Button btnEditar;
        private Panel panel1;
        private ComboBox comboBox1;
        private Button button1;
        private TextBox textBox1;
        private Label label1;
        private Button button2;
        private Panel panel2;
        private Button btnAgregar;
        private ComboBox comboBox4;
        private Label label2;
        private ComboBox comboBox5;
        private Label label3;
        private Label label4;
        private TextBox txtUser;
        private Label label19;
        private Label label20;
        private Label label21;
        private TextBox txtApellidos;
        private TextBox txtNombres;
        private TextBox txtcedula;
        private Panel panel9;
        private DataGridView dgvAgregar;
        private Label label22;
        private TextBox txtContrasenia;
    }
}